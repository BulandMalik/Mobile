//
//  SettingsViewController.h
//  tipcalculator
//
//  Created by Naeim Semsarilar on 12/21/14.
//  Copyright (c) 2014 naeim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController

@end
