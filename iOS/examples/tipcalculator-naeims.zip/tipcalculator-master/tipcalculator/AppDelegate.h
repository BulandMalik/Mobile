//
//  AppDelegate.h
//  tipcalculator
//
//  Created by Naeim Semsarilar on 12/20/14.
//  Copyright (c) 2014 naeim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
